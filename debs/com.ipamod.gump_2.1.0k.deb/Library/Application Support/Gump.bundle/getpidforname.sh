#!/bin/bash
if [ $# -eq 0 ]
  then
    echo "ERROR: First argument must be the name of the process.";
    exit 1
fi
ps ax -o pid= -o comm= | grep $1 | grep -v grep | xargs | cut -d " " -f1