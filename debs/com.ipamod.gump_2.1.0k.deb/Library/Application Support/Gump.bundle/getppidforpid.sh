#!/bin/bash
if [ $# -eq 0 ]
  then
    echo "ERROR: First argument must be the pid of the process.";
    exit 1
fi
w=$( ps $1 -o ppid= | xargs | cut -d " " -f1 )
while [[ $w -gt 1 ]]
  do
    echo "$w "
    w = ps $1 -o ppid= | xargs | cut -d " " -f1
done