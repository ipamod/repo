(a,c,p,r,k){k=document.createElement("canvas");k.width=1;k.height=a;return k.toDataURL("image/png")}
